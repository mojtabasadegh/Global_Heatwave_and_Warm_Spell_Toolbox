function varargout = subpart(varargin)
% SUBPART MATLAB code for subpart.fig
%      SUBPART, by itself, creates a new SUBPART or raises the existing
%      singleton*.
%
%      H = SUBPART returns the handle to a new SUBPART or the handle to
%      the existing singleton*.
%
%      SUBPART('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SUBPART.M with the given input arguments.
%
%      SUBPART('Property','Value',...) creates a new SUBPART or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before subpart_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to subpart_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help subpart

% Last Modified by GUIDE v2.5 23-Aug-2017 10:36:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @subpart_OpeningFcn, ...
    'gui_OutputFcn',  @subpart_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before subpart is made visible.
function subpart_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to subpart (see VARARGIN)

% Choose default command line output for subpart
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes subpart wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%  feed dropdown list
a=getappdata(0,'send_items');
set(handles.drp_province,'string',a);
set(handles.drp_subprovince, 'visible', 'off');
set(handles.text3, 'visible', 'off');

% --- Outputs from this function are returned to the command line.
function varargout = subpart_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in drp_province.
function drp_province_Callback(hObject, eventdata, handles)
% hObject    handle to drp_province (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns drp_province contents as cell array
%        contents{get(hObject,'Value')} returns selected item from drp_province
global province_shape
global subprovince_shape
global continent_shape
if ~isempty(continent_shape)
    continent_choose_value=get(handles.drp_province,'value');
    coordinate=[{continent_shape(continent_choose_value).X},{continent_shape(continent_choose_value).Y}];
    setappdata(0,'country_address',continent_shape(continent_choose_value).CONTINENT);
    setappdata(0,'coor_0',coordinate);
    setappdata(0,'coor_1',[]);
    delete(handles.figure1);
    return
else
    province_choose_value=get(handles.drp_province,'value')-1;
    if province_choose_value==0
        if isfield(province_shape(1),'ISO')==1
            setappdata(0,'country_address',province_shape(1).ISO);
        elseif isfield(province_shape(1),'STUSPS')==1
            setappdata(0,'country_address',province_shape(1).STUSPS);
        end
        setappdata(0,'coor_1',[]);
        delete(handles.figure1);
        return
    else
        coordinate=[{province_shape(province_choose_value).X},{province_shape(province_choose_value).Y}];
        setappdata(0,'coor_1',coordinate);
    end
    if isfield(province_shape(1),'ISO')==1
        country_choose_ISO=province_shape(province_choose_value).ISO;
    elseif isfield(province_shape(1),'STUSPS')==1
        country_choose_ISO=province_shape(province_choose_value).STUSPS;
    end
    %
    if exist(strcat('./shapefiles/',country_choose_ISO,'_adm2.shp'))
        set(handles.drp_subprovince, 'visible', 'on');
        set(handles.text3, 'visible', 'on');
        subprovince_shape=shaperead(strcat('./shapefiles/',country_choose_ISO,'_adm2.shp'));
        province_list_ID={subprovince_shape(:).ID_1};
        %
        city_index=find([province_list_ID{:}]==province_choose_value);
        city_list={subprovince_shape(city_index).NAME_2};
        city_list=[{'all part'},city_list];
        setappdata(0,'country_address',strcat(country_choose_ISO,'>>',province_shape(province_choose_value).NAME_1));
        set(handles.drp_subprovince,'string',city_list);
    else
        set(handles.drp_subprovince, 'visible', 'off');
        set(handles.text3, 'visible', 'off');
        if get(handles.drp_province,'value')~=1
            province_choose_index=get(handles.drp_province,'value');
            province_list=get(handles.drp_province,'string');
            province_value=province_list{province_choose_index};
            %
            if isfield(province_shape(1),'NAME_1')==1
                province_index=find(ismember({province_shape(:).NAME_1},province_value)>0);
            elseif isfield(province_shape(1),'NAME')==1
                province_index=find(ismember({province_shape(:).NAME},province_value)>0);
            end
            %
      
            coordinate=[{province_shape(province_index).X},{province_shape(province_index).Y}];
            setappdata(0,'coor_1',coordinate);
            setappdata(0,'country_address',strcat(country_choose_ISO,'>>',province_list{province_choose_index}));
            delete(handles.figure1);
        end
    end
end

% --- Executes during object creation, after setting all properties.
function drp_province_CreateFcn(hObject, eventdata, handles)
% hObject    handle to drp_province (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in drp_subprovince.
function drp_subprovince_Callback(hObject, eventdata, handles)
% hObject    handle to drp_subprovince (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns drp_subprovince contents as cell array
%        contents{get(hObject,'Value')} returns selected item from drp_subprovince
global subprovince_shape
if get(handles.drp_subprovince,'value')~=1
    subprovince_choose_index=get(handles.drp_subprovince,'value');
    subprovince_list=get(handles.drp_subprovince,'string');
    subprovince_value=subprovince_list{subprovince_choose_index};
    subprovince_index=find(ismember({subprovince_shape(:).NAME_2},subprovince_value)>0);
    coordinate=[{subprovince_shape(subprovince_index).X},{subprovince_shape(subprovince_index).Y}];
    setappdata(0,'coor_2',coordinate);
    setappdata(0,'country_address',strcat(getappdata(0,'country_address'),'>>',subprovince_list{subprovince_choose_index}));
    delete(handles.figure1);
else
    setappdata(0,'country_address',strcat(getappdata(0,'country_address')));
    delete(handles.figure1);
    return
end


% --- Executes during object creation, after setting all properties.
function drp_subprovince_CreateFcn(hObject, eventdata, handles)
% hObject    handle to drp_subprovince (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
