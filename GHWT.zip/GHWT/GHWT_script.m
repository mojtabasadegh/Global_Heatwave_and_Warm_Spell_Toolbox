function varargout = GHWT_script(handles)
clc

%check result folder exist or Not
if ~exist('./result')
    mkdir('./result')
end
if ~exist('./result/figures')
    mkdir('./result/figures');
end
load('./result/coordinate')
%get parameters from gui
consecutive_day_num=handles.txt_consecusive_day;
temperature=handles.txt_temperature;
start_year=handles.startyear;
end_year=handles.endyear;
pdf_plusmines=handles.txt_plusminus;
startsummerday=day(datetime(handles.txt_summer_start),'dayofyear');
endsummerday=day(datetime(handles.txt_summer_end),'dayofyear');
startsummerday_s=day(datetime(handles.txt_summer_start_s),'dayofyear');
endsummerday_s=day(datetime(handles.txt_summer_end_s),'dayofyear');
percentile_threshold=handles.txt_percentile_threshold;
ehf_scale=handles.txt_ehfscale;
%
disp('Please Wait ...')
% load saved data
[data,type]=choose_data_type(handles);

length_heatwave_data=[];
if handles.radio_pdf==1 %PDF method
    save_fig=handles.chk_eachfig;  %check savetxt checkbox checked
    threshold_data=pdf_threshold(data,pdf_plusmines,percentile_threshold);
    [heatwave_data,length_heatwave_data,binary_result]=calc_pdf_heatwave_event(data,threshold_data,consecutive_day_num,[],[],start_year,end_year);
    plot_heatwave_event_temp(heatwave_data,start_year,end_year,save_fig,target_coordinate{1},target_coordinate{2})
elseif handles.radio_temp==1 %Constant method
    save_fig=handles.chk_eachfig;
    [heatwave_data,length_heatwave_data,binary_result]=calc_temperature_heatwave(data,[],consecutive_day_num,temperature,start_year,end_year);
    plot_heatwave_event_temp(heatwave_data,start_year,end_year,save_fig,target_coordinate{1},target_coordinate{2})
elseif handles.radio_summer==1%Summer method
    save_fig=handles.chk_eachfig;
    neg_cell_index=[];
    if min(target_coordinate{2})<0 && max(target_coordinate{2})>0
        hemisphere_type='B'; %both hemisphere
        lat_data=load('./result/lat_data');
        [~,pos_cell_index]=min(abs(lat_data.lat_data-max(target_coordinate{2})));
        [~,neg_cell_index]=min(abs(lat_data.lat_data-min(target_coordinate{2})));
    elseif min(target_coordinate{2})>0 && max(target_coordinate{2})>0
        hemisphere_type='N';
    elseif min(target_coordinate{2})<0 && max(target_coordinate{2})<0
        hemisphere_type='S';
    end
    all_summer_data=calc_summerdata(data,startsummerday,endsummerday,startsummerday_s,endsummerday_s,percentile_threshold,hemisphere_type,neg_cell_index);
    [heatwave_data,length_heatwave_data,binary_result]=calc_temperature_heatwave(data,all_summer_data,consecutive_day_num,[],start_year,end_year);
    plot_heatwave_event_temp(heatwave_data,start_year,end_year,save_fig,target_coordinate{1},target_coordinate{2})
elseif handles.radio_ehf==1
    save_fig=handles.chk_eachfig;
    [data_all_temp,mean_per_30_temp,mean_next_2_temp]=cal_per_next_temp(data);
    EHF=cal_EHF(data_all_temp,mean_per_30_temp,mean_next_2_temp);
    [heatwave_data,binary_result]=process_EHF(EHF,data,start_year,end_year,ehf_scale);
    plot_heatwave_event_ehf(heatwave_data,start_year,end_year,save_fig,target_coordinate{1},target_coordinate{2});
end
%%
% calculate first day, last day, longest and ... of heatwave
[First_HW_DOY,Last_HW_DOY,Length_Longest_HW,HW_Magnitude_HWM,HW_Amplitude_HWA]=create_summary(binary_result,data,consecutive_day_num);
% plot first day, last day, longest and ...
for plot_name={'First_HW_DOY','Last_HW_DOY','Length_Longest_HW','HW_Magnitude_HWM','HW_Amplitude_HWA'};
    switch plot_name{1}
        case 'First_HW_DOY'
            plot_heatwave_others(First_HW_DOY,start_year,end_year,target_coordinate{1},target_coordinate{2},'First_HW_DOY',save_fig)
        case 'Last_HW_DOY'
            plot_heatwave_others(Last_HW_DOY,start_year,end_year,target_coordinate{1},target_coordinate{2},'Last_HW_DOY',save_fig)
        case 'Length_Longest_HW'
            plot_heatwave_others(Length_Longest_HW,start_year,end_year,target_coordinate{1},target_coordinate{2},'Length_Longest_HW',save_fig)
        case 'HW_Magnitude_HWM'
            plot_heatwave_others(HW_Magnitude_HWM,start_year,end_year,target_coordinate{1},target_coordinate{2},'HW_Magnitude_HWM',save_fig)
        case 'HW_Amplitude_HWA'
            plot_heatwave_others(HW_Amplitude_HWA,start_year,end_year,target_coordinate{1},target_coordinate{2},'HW_Amplitude_HWA',save_fig)
    end
end
%%
% plot HW duration
if  ~isempty(length_heatwave_data)
    save_fig=handles.chk_eachfig;
    plot_heatwave_duration(length_heatwave_data,start_year,end_year,save_fig,target_coordinate{1},target_coordinate{2})
end
%% save variables
list_year_exist=find(cellfun(@(x) ~isempty(x),binary_result(:,1))==1);
mm_i=1;
m_size=size(data{1,2},1);
n_size=size(data{1,2},2);
%% save all process data. i.e. first/last day of HW and etc.
for year_index=list_year_exist'
    GHWT_results.binary_result1(mm_i).year=binary_result{year_index,1};
    GHWT_results.binary_result1(mm_i).data=reshape(transpose(binary_result{year_index,2}),[m_size,n_size,size(binary_result{year_index,2},1)]);
    %
    GHWT_results.events(mm_i).year=heatwave_data{year_index,1};
    if size(heatwave_data,2)>2
        fff=reshape(heatwave_data(year_index,2:end),[m_size,n_size]);
        GHWT_results.events(mm_i).data=cellfun(@(x) length(x),fff);
    else
        fff=reshape(heatwave_data{year_index,2},[m_size,n_size]);
        GHWT_results.events(mm_i).data=fff;
    end
    %
    GHWT_results.First_HW_DOY(mm_i).year=First_HW_DOY{year_index,1};
    GHWT_results.First_HW_DOY(mm_i).data=First_HW_DOY{year_index,2};
    %
    GHWT_results.Last_HW_DOY(mm_i).year=Last_HW_DOY{year_index,1};
    GHWT_results.Last_HW_DOY(mm_i).data=Last_HW_DOY{year_index,2};
    %
    GHWT_results.Length_Longest_HW(mm_i).year=Length_Longest_HW{year_index,1};
    GHWT_results.Length_Longest_HW(mm_i).data=reshape(Length_Longest_HW{year_index,2:end},[m_size,n_size]);
    %
    GHWT_results.HW_Magnitude_HWM(mm_i).year=HW_Magnitude_HWM{year_index,1};
    GHWT_results.HW_Magnitude_HWM(mm_i).data=HW_Magnitude_HWM{year_index,2};
    %
    GHWT_results.HW_Amplitude_HWA(mm_i).year=HW_Amplitude_HWA{year_index,1};
    GHWT_results.HW_Amplitude_HWA(mm_i).data=HW_Amplitude_HWA{year_index,2};
    %
    if ~isempty(length_heatwave_data)
        GHWT_results.days(mm_i).year=length_heatwave_data{year_index,1};
        fff=reshape(length_heatwave_data(year_index,2:end),[m_size,n_size]);
        GHWT_results.days(mm_i).data=cellfun(@(x) sum(x),fff);
    end
    mm_i=mm_i+1;
end
save('./result/GHWT_results','GHWT_results')
%%
disp('Done.')
%load request data type
function [data,type]=choose_data_type(handles)
if handles.radio_tmean==1
    load('./result/data_combined');
    data=data_combined{1,1};
    type='mean';
elseif handles.radio_tmax==1
    load('./result/data_tmax');
    data=data_tmax{1,1};
    type='max';
elseif handles.radio_tmin==1
    load('./result/data_tmin');
    data=data_tmin{1,1};
    type='min';
end
%%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$       cal_EHF    $$$$$$$$$$$$$$$$$
function EHF=cal_EHF(data_all_temp,mean_per_30_temp,mean_next_2_temp)
%second step in calculating EHF
%purpose : calculate EHF base on Eq 4 Narin and Fawcett (2013)
% inputs:
%data_all_temp: arrange temperature data
%mean_per_30_temp : 30 perivous temperature day data
%mean_next_2_temp : 30 next temperature day data
%percentile_threshold : percentile value

%Refrence : 
%Nairn, J. R., & Fawcett, R. G. (2013). Defining heatwaves: heatwave defined as
%      a heat-impact event servicing all community and business sectors in Australia.
%      Centre for Australian Weather and Climate Research.

h_waiter = waitbar(0,'Please wait...','Name','Calculate EHF');
% calculate 95 percentile of temperature for each coordinate
T_daily_period=prctile(data_all_temp(:,3:end),95);
%
for index=31:size(mean_next_2_temp,1)
    EHI_sig(index,:)=mean_next_2_temp(index,:)-T_daily_period;%prctile(T_daily_period,percentile_threshold);
    EHI_accl(index,:)=mean_next_2_temp(index,:)-mean_per_30_temp(index,:);
    EHF(index,:)=EHI_sig(index,:).*max(1,EHI_accl(index,:));
    %
    waitbar(index/size(mean_next_2_temp,1));
end

EHF=[data_all_temp(1:end-3,1:2),EHF];
%save('./result/EHF','EHF','-v7.3')

delete(h_waiter);
%% $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     create_summary          $$$$$$$$$$$$$$$$
function [database_First_HW_DOY,database_Last_HW_DOY,database_Length_Longest_HW,database_HW_Magnitude_HWM,database_HW_Amplitude_HWA]=create_summary(database_HW_data,database_temp_data,consecutive_day_num)
% Create summary of HW records i.e. first days/last day of year HW occured and ...
database_First_HW_DOY={};
database_Last_HW_DOY={};
database_Length_Longest_HW={};
database_HW_Magnitude_HWM={};
database_HW_Amplitude_HWA={};
database_temp_data2={};
for iii=1:size(database_temp_data,1)
    database_temp_data2{iii,1}=reshape(database_temp_data{iii,2},[],size(database_temp_data{iii,2},3));
end
%
m_size=size(database_temp_data{1,2},1);
n_size=size(database_temp_data{1,2},2);
%
for year=1:size(database_HW_data,1)
    Frequency_HW_Events=[];
    Frequency_HW_Days=[];
    First_HW_DOY=[];
    Last_HW_DOY=[];
    Length_Longest_HW=[];
    Length_Shortest_HW=[];
    HW_Magnitude_HWM=[];
    HW_Amplitude_HWA=[];
    %
    HW_data=transpose(database_HW_data{year,2});
    temp_data=database_temp_data2{year,1};
    %
    for i=1:size(HW_data,1)
        %disp(i)
        dd=HW_data(i,:)';
        datazero=[0;find(dd==0 | isnan(dd));length(dd)+1];
        datadiffzero=diff(datazero);
        nmnm=find(datadiffzero>1);
        qwqw=datadiffzero(find(datadiffzero>1))-1;
        if length(find(isnan(dd)))==size(dd,1)
            Frequency_HW_Events(1,i)=nan;
            Frequency_HW_Days(1,i)=nan;
            First_HW_DOY(1,i)=nan;
            Last_HW_DOY(1,i)=nan;
            Length_Longest_HW(1,i)=nan;
            Length_Shortest_HW(1,i)=nan;
            HW_Magnitude_HWM(1,i)=nan;
            HW_Amplitude_HWA(1,i)=nan;
        else
            Frequency_HW_Events(1,i)=length(nmnm);
            Frequency_HW_Days(1,i)=sum(qwqw);
            if length(nmnm)>0
                if length(nmnm)==1 && sum(qwqw)==size(HW_data,2)
                    First_HW_DOY(1,i)=1;
                    Last_HW_DOY(1,i)=size(HW_data,2);
                else
                    First_HW_DOY(1,i)=datazero(nmnm(1))+1;
                    Last_HW_DOY(1,i)=datazero(nmnm(length(nmnm)))+1;
                end
                Length_Longest_HW(1,i)=max(consecutive_day_num,max(qwqw));
                Length_Shortest_HW(1,i)=max(consecutive_day_num,min(qwqw));
                temporary_temp_data={};
                for ii=1:length(qwqw)
                    temporary_temp_data{1,ii}=temp_data(i,datazero(nmnm(ii))+1:datazero(nmnm(ii))+qwqw(ii));
                end
                HW_Magnitude_HWM(1,i)=nanmean(cellfun(@nanmean,temporary_temp_data));
                [~,wewe]=nanmax(cellfun(@nansum,temporary_temp_data));
                HW_Amplitude_HWA(1,i)=max(temporary_temp_data{wewe});
            end
        end
        
    end
    if size(First_HW_DOY,2)<size(database_temp_data2{1},1)
        First_HW_DOY(1,i)=0;
        Last_HW_DOY(1,i)=0;
        Length_Longest_HW(1,i)=0;
        Length_Shortest_HW(1,i)=0;
        HW_Magnitude_HWM(1,i)=0;
        HW_Amplitude_HWA(1,i)=0;
    end
    %database_Frequency_HW_Events=reshape(Frequency_HW_Events,[720,360]);
    if ~isempty(database_HW_data{year,1})
        database_First_HW_DOY{year,1}=database_HW_data{year,1};
        database_Last_HW_DOY{year,1}=database_HW_data{year,1};
        database_Length_Longest_HW{year,1}=database_HW_data{year,1};
        database_HW_Magnitude_HWM{year,1}=database_HW_data{year,1};
        database_HW_Amplitude_HWA{year,1}=database_HW_data{year,1};
        %database_temp_data  database_Frequency_HW_Days=reshape(Frequency_HW_Days,[720,360]);
        database_First_HW_DOY{year,2}=reshape(First_HW_DOY,[m_size,n_size]);
        database_Last_HW_DOY{year,2}=reshape(Last_HW_DOY,[m_size,n_size]);
        database_Length_Longest_HW{year,2}=reshape(Length_Longest_HW,[m_size,n_size]);
        %database_Length_Shortest_HW=reshape(Length_Shortest_HW,[720,360]);
        database_HW_Magnitude_HWM{year,2}=reshape(HW_Magnitude_HWM,[m_size,n_size]);
        database_HW_Amplitude_HWA{year,2}=reshape(HW_Amplitude_HWA,[m_size,n_size]);
    end
end

%% $$$$$$$$$$$$$$$$$$$$$   cal_per_next_temp   $$$$$$$$$$$$$$$$
function [data_all_temp,mean_per_30_temp,mean_next_2_temp]=cal_per_next_temp(data)
%First step in calculating EHF
%purpose: calculate 30 perivous day and 2 next day temperature base on Eq 1
%and 3 Narin and Fawcett (2013)

%input
%data: a 3D matrix-temperature data

%Refrence : 
%Nairn, J. R., & Fawcett, R. G. (2013). Defining heatwaves: heatwave defined as
%      a heat-impact event servicing all community and business sectors in Australia.
%      Centre for Australian Weather and Climate Research.

h_waiter = waitbar(0,'Please wait...','Name','Calculate EHI');

%convert 3d Temperature matrix to 2D with size(coordinate temperature,days)
%arrange all temperature data
data_all_temp=[];
for year=1:size(data,1)
    dd=reshape(data{year,2},[],size(data{year,2},3));
    ddd=transpose(dd);
    data_all_temp=[data_all_temp;[str2num(data{year,1})*ones([size(ddd,1),1]),(1:size(ddd,1))',ddd]];
end
%% 
%calculate 30 perivous day and 2 next day temperature
for index=31:size(data_all_temp,1)-3
    mean_per_30_temp(index,:)=nanmean(data_all_temp(index-30:index-1,3:end));
    mean_next_2_temp(index,:)=nanmean(data_all_temp(index:index+2,3:end));
    
    waitbar(index/size(data_all_temp,1));
end

delete(h_waiter);

%% $$$$$$$$$$$$$$$$$$$$$$$$   calc_pdf_heatwave_event   $$$$$$$$$$
function [output,length_heatwave_data,binary_result]=calc_pdf_heatwave_event(data,threshold_data,consecutive_day_num,start_summer,end_summer,start_year,end_year)
%purpose : calculate Heatwave event/duration base on PDF method
%error
%Input :
% data : a 3D matrix-temperature data
% threshold_data : PDF threshold
% consecutive_day_num : consecusive days
% start_year : start year
% end_year : end year
% start_summer :start summer day (for PDF method base on summer data)
% end_summer : end summer day (for PDF method base on summer data)

% Refrence:
% Stefanon, M., D�Andrea, F., & Drobinski, P. (2012). Heatwave classification over
%       Europe and the Mediterranean region. Environmental Research Letters, 7(1), 014023.

% find index of start/end year
start_y=find(ismember(data(:,1),num2str(start_year))>0);
end_y=find(ismember(data(:,1),num2str(end_year))>0);
%
heatwave_data{size(data,1),1}={};
heatwave_data(:)={'0'};
length_heatwave_data{size(data,1),1}={};
length_heatwave_data(:)={'0'};
%
binary_result={};
for year=start_y:end_y
    heatwave_data{year,1}=data{year,1};
    length_heatwave_data{year,1}=data{year,1};
    convert_data=reshape(data{year,2},[],size(data{year,2},3));
    %
    binary_result{year,1}=data{year,1};
    binary_result{year,2}=transpose(zeros(size(convert_data)));
    for coordinate=1:size(convert_data,1)
        thresh=threshold_data(:,coordinate)';
        
        dd=convert_data(coordinate,:);
        %PDF method base on summer data (Extract just summer threshold/temperature day data)
        if ~isempty(start_summer) && ~isempty(end_summer)
            thresh=thresh(start_summer:end_summer);
            dd=dd(start_summer:end_summer);
        end
        % leap year
        if size(dd,2)==366
            dd=[dd(1,1:59),dd(61:end)];
        end
        
        if length(find(isnan(dd)))>65   % more than 65 missed data, not process
            heatwave_data{year,coordinate+1}=-1;
            length_heatwave_data{year,coordinate+1}=-1;
            %
            nan_item=find(isnan(dd'));
            binary_result{year,2}(nan_item,coordinate)=nan;
        else
            % algorithm in order to find event (find event days bigger-equal consecutive day)
            matrix_data=zeros(size(dd'));
            matrix_data(dd'>thresh')=1;
            
            datazero=[0;find(matrix_data==0 | isnan(matrix_data));length(matrix_data)+1];
            datadiffzero=diff(datazero);
            datafinddifzero=find(datadiffzero>consecutive_day_num);
            % heatwave event
            heatwave_data{year,coordinate+1}=datafinddifzero;    % heatwave event number
            % duration heatwave
            length_heatwave_data{year,coordinate+1}=datadiffzero(find(datadiffzero>consecutive_day_num))-1; %$$ total heatwave (durations)
            for ii=1:size(datafinddifzero,1)
                index_1=datazero(datafinddifzero(ii),1);
                %index_2=datazero(datafinddifzero(ii)+1,1);
                days_duration=datadiffzero(datafinddifzero(ii),1);
                binary_result{year,2}(index_1+1:index_1+days_duration-1,coordinate)=int8(1);
            end
            nan_item=find(isnan(dd'));
            binary_result{year,2}(nan_item,coordinate)=nan;
        end
    end
    
end
output=heatwave_data;

%%  $$$$$$$$$$$$$$$$$$$$$$$$$$$$    calc_summerdata   $$$$$$$
function output=calc_summerdata(data,start_day_N,end_day_N,start_day_S,end_day_S,threshold_percentile,hemisphere_type,neg_cell_index)
% purpose : calculate summer threshold for each coordinate

% Input :
% data : a 3D matrix-temperature data
% start_day : summer start day
% end_day : summer end day
%threshold_percentile : threshold

h_waiter = waitbar(0,'Please wait...','Name','Calculate Summer Data');

pause(1)
% check last year has compelete data (all days data)
exceptyear=0;
if end_day_N>size(data{end,2},3)
    exceptyear=1;
    disp(strcat('remove ',num2str(data{end,1}),' from summer processing'))
end

all_summer_data_N=[];
all_summer_data_S=[];
for year=1:size(data,1)-exceptyear
    dd_thisyear=data{year,2};
    % selected country is in north hemisphere
    if strcmp(hemisphere_type,'N')
        ddd_N=dd_thisyear(:,:,start_day_N:end_day_N);
        all_summer_data_N=[all_summer_data_N,reshape(ddd_N,[],size(ddd_N,3))];
    elseif strcmp(hemisphere_type,'S')
        if (year+1)<=size(data,1)
            dd_nextyear=data{year+1,2};
            ddd1=dd_thisyear(:,:,start_day_S:size(dd_thisyear,3));
            if end_day_S>=59 && size(dd_nextyear,3)==366
                end_day_S=end_day_S+1;
            end
            ddd2=dd_nextyear(:,:,1:end_day_S);
            ddd_S=[reshape(ddd1,[],size(ddd1,3)),reshape(ddd2,[],size(ddd2,3))];
            all_summer_data_S=[all_summer_data_S,ddd_S];
        end
    elseif strcmp(hemisphere_type,'B') %both(north and south) hemisphere
        ddd_N=dd_thisyear(:,:,start_day_N:end_day_N);
        dd_nextyear=data{year+1,2};
        ddd1=dd_thisyear(:,:,start_day_S:size(dd_thisyear,3));
        if end_day_S==59 && size(dd_nextyear,3)==366
            end_day_S=60;
        end
        ddd2=dd_nextyear(:,:,1:end_day_S);
        ddd_S=[reshape(ddd1,[],size(ddd1,3)),reshape(ddd2,[],size(ddd2,3))];
        %
        all_summer_data_N=[all_summer_data_N,reshape(ddd_N,[],size(ddd_N,3))];
        all_summer_data_S=[all_summer_data_S,ddd_S];
    end
    
    waitbar(year/(size(data,1)-exceptyear));
end
% calculate percentile threshold
if isempty(all_summer_data_N)
    all_summer_data=all_summer_data_S;
    ee=prctile(all_summer_data,threshold_percentile,2);
elseif isempty(all_summer_data_S)
    all_summer_data=all_summer_data_N;
    ee=prctile(all_summer_data,threshold_percentile,2);
else
    mnm=(neg_cell_index+1-180)*size(data{1,2},1);
    ee1=prctile(all_summer_data_N(1:size(all_summer_data_N,1)-mnm,:),threshold_percentile,2);
    ee2=prctile(all_summer_data_S(size(all_summer_data_N,1)-mnm+1:end,:),threshold_percentile,2);
    ee=[ee1;ee2];
end

pause(1)
delete(h_waiter)
output=ee;

%% $$$$$$$$$$$$$$$$$$$$$$$$$$$   calc_temperature_heatwave  $$$$$$
function [output,length_heatwave_data,binary_result]=calc_temperature_heatwave(data,all_summer_data,consecutive_day_num,temperature,start_year,end_year)
%#################
%HW_Record_Constant_Threshold_TMAX_35_ConsDays_4_2014 last days have problem
%HW_Record_Constant_Threshold_TMAX_35_ConsDays_4_2015 first days
%################
%purpose : calculate Heatwave event/duration base on temperature/summer method

%Input :
% data : a 3D matrix-temperature data
% all_summer_data : summer data threshold (for summer method)
% consecutive_day_num : consecusive days
% temperature : temperature threshold (for temperature method)
% start_year : start year
% end_year : end year

% find index of start/end year
start_y=find(ismember(data(:,1),num2str(start_year))>0);
end_y=find(ismember(data(:,1),num2str(end_year))>0);

%initialize
heatwave_data{size(data,1),1}={};
heatwave_data(:)={'0'};
length_heatwave_data{size(data,1),1}={};
length_heatwave_data(:)={'0'};
%
binary_result={};
for year=start_y:end_y
    heatwave_data{year,1}=data{year,1};
    length_heatwave_data{year,1}=data{year,1};
    convert_data=reshape(data{year,2},[],size(data{year,2},3));
    %
    binary_result{year,1}=data{year,1};
    binary_result{year,2}=transpose(zeros(size(convert_data)));
    for coordinate=1:size(convert_data,1)
        if isempty(temperature)
            threshold=all_summer_data(coordinate,1);%*scale;
        else
            threshold=temperature;
        end
        dd=convert_data(coordinate,:);
        
        if length(find(isnan(dd)))>65    % more than 65 missed data, ignore
            heatwave_data{year,coordinate+1}=-1;
            length_heatwave_data{year,coordinate+1}=-1;
            %
            nan_item=find(isnan(dd'));
            binary_result{year,2}(nan_item,coordinate)=nan;
        else
            % algorithm in order to find event (find event days bigger-equal consecutive day)
            matrix_data=zeros(size(dd'));
            matrix_data(dd>threshold)=1;
            
            datazero=[0;find(matrix_data==0 | isnan(matrix_data));length(matrix_data)+1];
            datadiffzero=diff(datazero);
            datafinddifzero=find(datadiffzero>consecutive_day_num);
            % heatwave event
            heatwave_data{year,coordinate+1}=datafinddifzero;
            % duration heatwave
            length_heatwave_data{year,coordinate+1}=datadiffzero(find(datadiffzero>consecutive_day_num))-1;
            for ii=1:size(datafinddifzero,1)
                index_1=datazero(datafinddifzero(ii),1);
                days_duration=datadiffzero(datafinddifzero(ii),1);
                binary_result{year,2}(index_1+1:index_1+days_duration-1,coordinate)=int8(1);
            end
            nan_item=find(isnan(dd'));
            binary_result{year,2}(nan_item,coordinate)=nan;
            
        end
    end
end

output=heatwave_data;

%% $$$$$$$$$$$$$$$$$$$    create_boundray   $$$$$$$$$$$$
function create_boundray(dir_tmax,dir_tmin,lat_country,lon_country)
%purpose : create mask map

%Input:
% dir_tmax : max Temperature data directory
% dir_tmin : min Temperature data directory
% lat_country : latitude coordinate of selected area
% lon_country : longitude coordinate of selected area

%
h_waiter = waitbar(0,'Please wait...','Name','Creating mask');
%
max_Pos=max(lon_country(lon_country>0));
min_Pos=min(lon_country(lon_country>0));
max_Neg=max(lon_country(lon_country<0));
min_Neg=min(lon_country(lon_country<0));
lat_data=[];
%
if ~isempty(dir_tmax)
    files_tmax=dir(strcat(dir_tmax,'/*.nc'));
    lat_data=ncread(fullfile(dir_tmax,files_tmax(1).name),'lat');
    long_data=ncread(fullfile(dir_tmax,files_tmax(1).name),'lon');
    files=files_tmax;
end
if ~isempty(dir_tmin)
    files_tmin=dir(strcat(dir_tmin,'/*.nc'));
    if isempty(lat_data)
        lat_data=ncread(fullfile(dir_tmin,files_tmin(1).name),'lat');
        long_data=ncread(fullfile(dir_tmin,files_tmin(1).name),'lon');
        files=files_tmin;
    end
end
% if ~isempty(dir_tmean)
%     files_tmean=dir(strcat(dir_tmean,'/*.nc'));
%     if isempty(lat_data)
%         lat_data=ncread(fullfile(dir_tmean,files_tmean(1).name),'lat');
%         long_data=ncread(fullfile(dir_tmean,files_tmean(1).name),'lon');
%         files=files_tmean;
%     end
% end
%%
if ~isempty(max_Pos) && isempty(max_Neg)  %country in positive longitude like Iran
    [~,max_long]=min(abs(long_data-max_Pos));
    [~,min_long]=min(abs(long_data-min_Pos));
    min_long=min_long-1;
    max_long=max_long+1;
elseif isempty(max_Pos) && ~isempty(max_Neg)  %country in Negative longitude like Argentina
    long_data(long_data>180)=long_data(long_data>180)-360;
    [~,min_long]=min(abs(long_data-min_Neg));
    [~,max_long]=min(abs(long_data-max_Neg));
    min_long=min_long-1;
    max_long=max_long+1;
elseif ~isempty(max_Pos) && ~isempty(max_Neg)  %country in both pos and neg longitude like usa
    long_data(long_data>180)=long_data(long_data>180)-360;
    if ~isempty(find(lon_country<0 & lon_country>-30))%min_Pos<90
        [~,min_long]=min(abs(long_data-min_Neg));
        [~,max_long]=min(abs(long_data-max_Pos));
        min_long=min_long-1;
        max_long=max_long+1;
    elseif isempty(find(lon_country<0 & lon_country>-30))%min_Pos>90
        [~,min_long]=min(abs(long_data-min_Pos));
        [~,max_long]=min(abs(long_data-max_Neg));
        min_long=min_long-1;
        max_long=max_long+1;
    else
        disp('error2')
    end
else
    disp('error')
end

%%
[~,lat_(1)]=min(abs(lat_data-max(lat_country)));
[~,lat_(2)]=min(abs(lat_data-min(lat_country)));
%rectangle around target country
min_lati=min(lat_)-1;
max_lati= max(lat_)+1;
% get nc files properties
first_long=long_data(1);
last_long=long_data(length(long_data));
first_lat=lat_data(1);
last_lat=lat_data(length(lat_data));
long_accuracy=long_data(2)-long_data(1);
lat_accuracy=lat_data(2)-lat_data(1);
%
if max_long<min_long         % country like algeria that have +- longitude coordinates
    longi_=[min_long:length(long_data),1:max_long];
    mask_map=zeros(length(longi_),max_lati-min_lati+1);
    for i=longi_
        for j=min_lati:max_lati
            lon_cor=first_long+(i-1)*long_accuracy;%0.25+(i-1)*0.5;
            lat_cor=first_lat+(j-1)*lat_accuracy;%89.75-(j-1)*0.5;
            if lon_cor>180
                lon_cor=lon_cor-360;
            end
            status=inpolygon(lon_cor,lat_cor,lon_country,lat_country);
            if status==1
                if i<min_long
                    x_ind=length(long_data)-min_long+i+1;
                    y_ind=j-min_lati+1;
                    mask_map(x_ind,y_ind)=1;
                else
                    x_ind=i-min_long+1;
                    y_ind=j-min_lati+1;
                    mask_map(x_ind,y_ind)=1;
                end
                try
                    mask_map(x_ind-1,y_ind-1)=1;
                    mask_map(x_ind-1,y_ind+0)=1;
                    mask_map(x_ind-1,y_ind+1)=1;
                    %
                    mask_map(x_ind+1,y_ind-1)=1;
                    mask_map(x_ind+1,y_ind+0)=1;
                    mask_map(x_ind+1,y_ind+1)=1;
                    %
                    mask_map(x_ind,y_ind-1)=1;
                    mask_map(x_ind,y_ind+1)=1;
                end
            end
        end
        waitbar(find(i==longi_)/length(longi_));
    end
else
    mask_map=zeros(max_long-min_long+1,max_lati-min_lati+1);
    %
    for i=min_long:max_long
        for j=min_lati:max_lati
            lon_cor=first_long+(i-1)*long_accuracy;%0.25+(i-1)*0.5;
            lat_cor=first_lat+(j-1)*lat_accuracy;%89.75-(j-1)*0.5;

            if lon_cor>180
                lon_cor=lon_cor-360;
            end
            status=inpolygon(lon_cor,lat_cor,lon_country,lat_country);
            if status==1
                x_ind=i-min_long+1;
                y_ind=j-min_lati+1;
                %center
                mask_map(x_ind,y_ind)=1;
                %
                try
                    mask_map(x_ind-1,y_ind-1)=1;
                    mask_map(x_ind-1,y_ind+0)=1;
                    mask_map(x_ind-1,y_ind+1)=1;
                    %
                    mask_map(x_ind+1,y_ind-1)=1;
                    mask_map(x_ind+1,y_ind+0)=1;
                    mask_map(x_ind+1,y_ind+1)=1;
                    %
                    mask_map(x_ind,y_ind-1)=1;
                    mask_map(x_ind,y_ind+1)=1;
                end
            end
        end
        waitbar((i-min_long)/(max_long-min_long));
    end
end
save('./result/mask_map','mask_map');
delete(h_waiter);
%% $$$$$$$$$$$$$$$$$$$$$$  plot_heatwave_event_ehf   $$$$$$$$$$$$$$$$$$$$$
function plot_heatwave_event_ehf(heatwave_data,start_year,end_year,save_fig,lon_con,lat_con)
% forth step to calculating EHF
% purpose : plot EHF data

%Input :
% heatwave_data : scaled EHF data
% start_year :  start year to calculate EHF
% end_year : end year to calculate EHF
% saveastxt : save Heatwave Event data as txt file

% load target country mask file
load('./result/mask_map')

start_y=find(ismember(heatwave_data(:,1),num2str(start_year))>0);
end_y=find(ismember(heatwave_data(:,1),num2str(end_year))>0);
%%
% checked save txt checkbok checked
% if saveastxt==1
%     fid=fopen('./result/Heatwave_event.txt','w');
% end
matrix=[];
% matrix_copy is a copy of matrix that mask file is not apply on it
matrix_copy=[];
h = figure('name','Events');
set(gcf,'color','w','units','normalized','position',[0.05 0.05 0.75 0.85],'paperpositionmode','auto');
%
for year=start_y:end_y
    matrix(year,:)=heatwave_data{year,2};
    matrix_copy(year,:)=heatwave_data{year,2};
    buni=reshape(mask_map,1,[]);
    %apply mask file on matrix data
    matrix(year,find(buni==0))=nan;%0;%min(min(data));
end

n = max(max(matrix));
if ~isempty(find(matrix==-1))
    heatwavecolormap=[[0,0,0;1,1,1];[ones(n-1,1) linspace(1,0,n-1)' zeros(n-1,1)]];%cmap];
else
    heatwavecolormap=[[1,1,1];[ones(n-1,1) linspace(1,0,n-1)' zeros(n-1,1)]];%cmap];
end
m=0;
for year=start_y:end_y
    m=m+1;
    dd=matrix(year,:);
    data=reshape(dd,size(mask_map,1),size(mask_map,2));
    %%
    if m==1
        Position=[0.1,0.75,0.2,0.2];
    else
        pos=get(fig(m-1),'position');
        newpos=[pos(1)+pos(3)+0.1,pos(2),pos(3),pos(4)];
        if newpos(1)>0.95
            newpos=[0.1, pos(2)-pos(4)-0.1,pos(3), pos(4) ];
        end
        Position=newpos;
    end
    %
    fig(m)=scrollsubplot(m,Position);
    %%
    data2=transpose(data);
    img_=imagesc(flipud(data2));
    set(img_,'Xdata',[min(lon_con) max(lon_con)])
    xlim([min(lon_con) max(lon_con)]);
    set(img_,'ydata',[min(lat_con) max(lat_con)])
    ylim([min(lat_con) max(lat_con)]);
    set (gca,'YDir','normal')
    if save_fig==1
        filename=sprintf('./result/figures/fig_%s_%s.jpg','Events',num2str(heatwave_data{year,1}));
        title_name=strcat('# Heatwave days', {' '} , num2str(heatwave_data{year,1}));
        save_each_fig(data2,filename,title_name,lon_con,lat_con,heatwavecolormap,min(min(matrix)),n)
    end
    colormap(fig(m),heatwavecolormap);
    hold on
    plot(lon_con,lat_con,'LineWidth',2)
    title(strcat('# Heatwave ', {' '} , num2str(heatwave_data{year,1})))
    xlabel('Longitude')
    ylabel('Latitude')
    %
    if save_fig==1
        filename=sprintf('./result/figures/fig_%s_%s.jpg','Events',num2str(heatwave_data{year,1}));
        title_name=strcat('# Heatwave days', {' '} , num2str(heatwave_data{year,1}));
        save_each_fig(data2,filename,title_name,lon_con,lat_con,heatwavecolormap,min(min(matrix)),n)
    end
    colormap(fig(m),heatwavecolormap);
%     if min_value==max_value
%         max_value=max_value+0.01*max_value;
%         min_value=min_value-0.01*min_value;
%     end
    caxis([min(min(matrix_copy)) n])
    pause(0.2)
end
colorbar('Position', [0.92  0.2  0.02  0.7])
% 
% if saveastxt==1
%     fclose(fid);
% end

%% $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$  plot_heatwave_duration  $$$$$$$$$$$$$$$$$
function plot_heatwave_duration(length_heatwave_data,start_year,end_year,save_fig,lon_con,lat_con)

% purpose : plot duration Heatwave data

%Input :
% length_heatwave_data : Heatwave duration
% start_year :  start year
% end_year : end year
% saveastxt : save Heatwave Event data as txt file

% load target country mask file
load('./result/mask_map')
start_y=find(ismember(length_heatwave_data(:,1),num2str(start_year))>0);
end_y=find(ismember(length_heatwave_data(:,1),num2str(end_year))>0);
%%
%I=edge(mask_map);
% checked save txt checkbok checked
% if saveastxt==1
%     fid=fopen('./result/Heatwave_duration.txt','w');
% end

matrix=[];
% matrix_copy is a copy of matrix that mask file is not apply on it
matrix_copy=[];
%%
h = figure('name','Duration');
set(gcf,'color','w','units','normalized','position',[0.05 0.05 0.75 0.85],'paperpositionmode','auto');
%%
for year=start_y:end_y
    
    for i=2:size(length_heatwave_data,2)
        if length_heatwave_data{year,i}==-1
            matrix(year,i-1)=nan;%-1;
        else
            matrix(year,i-1)=sum(length_heatwave_data{year,i});
        end
    end
    % end
    matrix_copy(year,:)=matrix(year,:);
    buni=reshape(mask_map,1,[]);
    %apply mask file on matrix data
    matrix(year,find(buni==0))=nan;%0;%min(min(data));
end

n = max(max(matrix));
if ~isempty(find(matrix==-1))
    heatwavecolormap=[[0,0,0;1,1,1];[ones(n-1,1) linspace(1,0,n-1)' zeros(n-1,1)]];%cmap];
else
    heatwavecolormap=[[1,1,1];[ones(n-1,1) linspace(1,0,n-1)' zeros(n-1,1)]];%cmap];
end
m=0;
for year=start_y:end_y
    m=m+1;
    dd=matrix(year,:);
    data=reshape(dd,size(mask_map,1),size(mask_map,2));
    %%
    if m==1
        Position=[0.1,0.75,0.2,0.2];
    else
        pos=get(fig(m-1),'position');
        newpos=[pos(1)+pos(3)+0.1,pos(2),pos(3),pos(4)];
        if newpos(1)>0.95
            newpos=[0.1, pos(2)-pos(4)-0.1,pos(3), pos(4) ];
        end
        Position=newpos;
    end
    %
    fig(m)=scrollsubplot(m,Position);
    %%
    data2=transpose(data);
    img_=imagesc(flipud(data2));
    set(img_,'Xdata',[min(lon_con) max(lon_con)])
    xlim([min(lon_con) max(lon_con)]);
    set(img_,'ydata',[min(lat_con) max(lat_con)])
    ylim([min(lat_con) max(lat_con)]);
    set (gca,'YDir','normal')
    colormap(fig(m),heatwavecolormap);
    hold on
    plot(lon_con,lat_con,'LineWidth',2)
    title(strcat('# Heatwave days', {' '} , num2str(length_heatwave_data{year,1})))
    xlabel('Longitude')
    ylabel('Latitude')
    
    if save_fig==1
        filename=sprintf('./result/figures/fig_%s_%s.jpg','days',num2str(length_heatwave_data{year,1}));
        title_name=strcat('# Heatwave days', {' '} , num2str(length_heatwave_data{year,1}));
        save_each_fig(data2,filename,title_name,lon_con,lat_con,heatwavecolormap,min(min(matrix)),n)
    end
    
    colormap(fig(m),heatwavecolormap);
%     if min_value==max_value
%         max_value=max_value+0.01*max_value;
%         min_value=min_value-0.01*min_value;
%     end
%     caxis([min(min(matrix_copy)) n])
    min_non_zero=min(min(matrix_copy(matrix_copy~=0)));
    if abs(min_non_zero-0)>5
        if abs(floor(min_non_zero)-min_non_zero)<0.5
            caxis([min_non_zero-1 n]);
        else
            caxis([min_non_zero n]);
        end
    else
        caxis([min(0,min(min(matrix_copy))) n]);
    end
    pause(0.2)
end
colorbar('Position', [0.92  0.2  0.02  0.7])

%% $$$$$$$$$$$$$$$$$$$$$$    pdf_threshold   $$$$$$$$$$$$$$$$$$$$$$$$$
function threshold=pdf_threshold(data,txt_plusminusdays_num,threshold_percental)
% purpose : calculate PDF threshold

% Input :
% data : a 3D matrix-temperature data
% txt_plusminusdays_num : +- number days for calculating PDF threshold
% threshold_percental : threshold percental

% Refrence:
% Stefanon, M., D�Andrea, F., & Drobinski, P. (2012). Heatwave classification over 
%       Europe and the Mediterranean region. Environmental Research Letters, 7(1), 014023.

h_waiter = waitbar(0,'Please wait...','Name','Calculate pdf');

data_all_temp=[];

%arrange temperature data
for year=1:size(data,1)
    dd=reshape(data{year,2},[],size(data{year,2},3));
    ddd=transpose(dd);
    data_all_temp=[data_all_temp;[str2num(data{year,1})*ones([size(ddd,1),1]),(1:size(ddd,1))',ddd]];
end

threshold=[];
if data_all_temp(end,2)<365
    except_year=1;
else
    except_year=0;
end
% for each day of year, calculate +-days of target day temperature
for day=1:365
    matrix=[];
    for year=min(data_all_temp(:,1)):max(data_all_temp(:,1))- except_year
        index=find(data_all_temp(:,1)==year & data_all_temp(:,2)==day);
        days_txt_plusminus=[index-txt_plusminusdays_num:index+txt_plusminusdays_num];
        %reset wrong data
        days_txt_plusminus(days_txt_plusminus<1)=1;
        days_txt_plusminus(days_txt_plusminus>size(data_all_temp,1))=size(data_all_temp,1);
        %
        dd=data_all_temp(unique(days_txt_plusminus),3:end);
        matrix=[matrix;dd];
    end
    threshold(end+1,:)=prctile(matrix,threshold_percental);
    waitbar(day/365);
end
% save threshold threshold
delete(h_waiter)

%% $$$$$$$$$$$$$$$$$$$$$$    mean_temp_maxmin    $$$$$$$$$$$$$$$$$
function mean_temp_maxmin(data_tmax,data_tmin)
% purpose : calculate mean temperature ((Tmax+Tmin)/2)

% Input :
% data_tmax : Tmax data
% data_tmin : Tmin data

h_waiter = waitbar(0,'Please wait...','Name','Process Tmean');
data_combined={};

for year=1:size(data_tmax{1,1},1)
    tmax_data=data_tmax{1,1}{year,2};
    tmin_data=data_tmin{1,1}{year,2};
    tmax_data(tmax_data<-1000)=nan;
    tmin_data(tmin_data<-1000)=nan;
    data_combined{1,1}{year,1}=data_tmax{1,1}{year,1};
    data_combined{1,1}{year,2}=(tmax_data+tmin_data)/2;
    waitbar(year/size(data_tmax{1,1},1));
end
save('./result/data_combined','data_combined','-v7.3')
delete(h_waiter)

%%  $$$$$$$$$$$$$$$$$$$$$$$    save_each_fig     $$$$$$$$$$$$$$$
function save_each_fig(data_plot,filename,title_name,lon_con,lat_con,heatwavecolormap,min_value,max_value)
newFig22=figure;
img_=imagesc(flipud(data_plot));
set(img_,'Xdata',[min(lon_con) max(lon_con)])
xlim([min(lon_con) max(lon_con)]);
%end
set(img_,'ydata',[min(lat_con) max(lat_con)])
ylim([min(lat_con) max(lat_con)]);
set (gca,'YDir','normal')
colormap(newFig22,heatwavecolormap);
hold on
plot(lon_con,lat_con,'LineWidth',2)
title(title_name)
xlabel('Longitude')
ylabel('Latitude')
colorbar()
caxis([min_value max_value])
if abs(max(lon_con)-min(lon_con))>abs(max(lat_con)-min(lat_con))
    aaaa=abs(max(lon_con)-min(lon_con))*newFig22.Position(4)/(abs(max(lat_con)-min(lat_con)));
else
    aaaa=(abs(max(lat_con)-min(lat_con)))*newFig22.Position(3)/abs(max(lon_con)-min(lon_con));
end
newFig22.Position=[newFig22.Position(1),newFig22.Position(2),aaaa,newFig22.Position(4)];
set(newFig22,'Units','Inches');
pos = get(newFig22,'Position');
set(newFig22,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(newFig22,filename,'jpg');
delete(newFig22);

%%  $$$$$$$$$$$$$$$$$$$$$$$$$$$$    process_EHF     %%%%%%%%%%%%%%%%%%%
function [heatwave_data,binary_result]=process_EHF(data_EHF,all_temperatur,start_year,end_year,ehf_scale)
% third step in calculating EHF
% purpose : set scale on EHF data

% input:
% data_EHF : EHF(data calculate base on Eq 4 Narin and Fawcett (2013))
% all_temperatur : arrange all temperature data
% start_year :  start year to calculate EHF
% end_year : end year to calculate EHF
% ehf_scale : EHF scale

%Refrence :
%Nairn, J. R., & Fawcett, R. G. (2013). Defining heatwaves: heatwave defined as
%      a heat-impact event servicing all community and business sectors in Australia.
%      Centre for Australian Weather and Climate Research.
% find index of start/end year
start_y=find(ismember(all_temperatur(:,1),num2str(start_year))>0);
end_y=find(ismember(all_temperatur(:,1),num2str(end_year))>0);

%initialize
heatwave_data{size(all_temperatur,1),1}={};
heatwave_data(:)={'0'};
binary_result{size(all_temperatur,1),1}={};
%binary_result(:)={'0'};
%
for year=start_y:end_y
    %m=m+1;
    dd_EHF=data_EHF(data_EHF(:,1)==str2num(all_temperatur{year,1}),3:end);
    dd_EHF2=transpose(dd_EHF);
    %index_year=find(ismember(all_temperatur(:,1),num2str(year))>0);
    dd_EHF2(dd_EHF2<ehf_scale)=0;
    matrix=(dd_EHF2>0);
    heatwave_data{year,1}=all_temperatur{year,1};
    heatwave_data{year,2}=sum(matrix,2)';
    %
    binary_result{year,1}=all_temperatur{year,1};
    nan_item=find(isnan(dd_EHF2));
    binary_res=int8(matrix);
    binary_res(nan_item)=nan;
    binary_result{year,2}=transpose(binary_res);
end

%% $$$$$$$$$$$$$$$$$$$$$$$$    plot_heatwave_others     $$$$$$$$$$$$$$$
function plot_heatwave_others(datatbase_data,start_year,end_year,lon_con,lat_con,database_type,save_fig)

% purpose : plot Heatwave First/last day, Amplitude, Magnitude, etc data

% Input :
% heatwave_data : Heatwave Event
% start_year :  start year
% end_year : end year
% saveastxt : save Heatwave Event data as txt file
% database_type

% load target country mask file
load('./result/mask_map')

start_y=find(cell2mat(cellfun(@(x) str2double(x)==start_year,datatbase_data(:,1),'UniformOutput',false))==1);
end_y=find(cell2mat(cellfun(@(x) str2double(x)==end_year,datatbase_data(:,1),'UniformOutput',false))==1);
%
matrix={};
% matrix_copy is a copy of matrix that mask file is not apply on it
matrix_copy={};
%%
h = figure('name',database_type);
set(gcf,'color','w','units','normalized','position',[0.05 0.05 0.75 0.85],'paperpositionmode','auto');
%%
for year=start_y:end_y
    matrix{year}=datatbase_data{year,2};
    matrix_copy{year}=datatbase_data{year,2};
    %apply mask file on matrix data
    matrix{year}(find(mask_map==0))=nan;%-1000;%min(min(data));
end
% get max and min value through all year to make a consistant plot
max_value = ceil(max(cell2mat(cellfun(@(x) max(max(x)),matrix,'UniformOutput',false))));
val_1 = floor(min(cell2mat(cellfun(@(x) min(min(x)),matrix_copy,'UniformOutput',false))));
val_2 = floor(min(cell2mat(cellfun(@(x) min(min(x)),matrix,'UniformOutput',false))));
min_non_zero=min(cell2mat(cellfun(@(x) min(min(x(x~=0))),matrix_copy,'UniformOutput',false)));
min_value=max(val_1,val_2);
%
if ~isempty(cell2mat(cellfun(@(x) find(x==-1), matrix,'UniformOutput',false)))
    heatwavecolormap=[[0,0,0;1,1,1];[ones(max_value-1,1) linspace(1,0,max_value-1)' zeros(max_value-1,1)]];%cmap];
else
    heatwavecolormap=[[1,1,1];[ones(max_value-1,1) linspace(1,0,max_value-1)' zeros(max_value-1,1)]];%cmap];
end
% plot each heatwave
m=0;
for year=start_y:end_y
    m=m+1;
    data=matrix{year};
    %%
    if m==1
        Position=[0.1,0.75,0.2,0.2];
    else
        pos=get(fig(m-1),'position');
        newpos=[pos(1)+pos(3)+0.1,pos(2),pos(3),pos(4)];
        if newpos(1)>0.95
            newpos=[0.1, pos(2)-pos(4)-0.1,pos(3), pos(4) ];
        end
        Position=newpos;
    end
    %
    fig(m)=scrollsubplot(m,Position);
    %%
    data2=transpose(data);
    %data2(data2==-1000)=min_value-1;
    img_=imagesc(flipud(data2));
    %
    set(img_,'Xdata',[min(lon_con) max(lon_con)])
    xlim([min(lon_con) max(lon_con)]);
    %
    set(img_,'ydata',[min(lat_con) max(lat_con)])
    ylim([min(lat_con) max(lat_con)]);
    set (gca,'YDir','normal')
    colormap(fig(m),heatwavecolormap);
    hold on
    plot(lon_con,lat_con,'LineWidth',2)
    title(strcat(strrep(database_type,'_',' '), {' '} , num2str(datatbase_data{year,1})))
    xlabel('Longitude')
    ylabel('Latitude')
    
    if save_fig==1
        filename=sprintf('./result/figures/fig_%s_%s.jpg',database_type,num2str(datatbase_data{year,1}));
        title_name=strcat(strrep(database_type,'_',' '), {' '} , num2str(datatbase_data{year,1}));
        save_each_fig(data2,filename,title_name,lon_con,lat_con,heatwavecolormap,min_value,max_value)
    end
    if min_value==max_value
       max_value=max_value+0.01*max_value;
       min_value=min_value-0.01*min_value;
    end
    if abs(min_non_zero-0)>5
        if abs(floor(min_non_zero)-min_non_zero)<0.5
            caxis([min_non_zero-1 max_value]);
        else
            caxis([min_non_zero max_value]);
        end
    else
        caxis([min(0,min_value) max_value]);
    end
    pause(0.2)
end
bbbp=colorbar('Position', [0.92  0.2  0.02  0.7]);
% colorbarticklables=bbbp.TickLabels;
% colorbarticklables{1}=num2str(min(data(data>0)));
% set(bbbp,'YTick',colorbarticklables)

%% $$$$$$$$$$$$$$$$$$$$$$$$$$$$$      plot_heatwave_event_temp    $$$$$$$$$
function plot_heatwave_event_temp(heatwave_data,start_year,end_year,save_fig,lon_con,lat_con)

% purpose : plot Heatwave Event data

% Input :
% heatwave_data : Heatwave Event
% start_year :  start year
% end_year : end year
% saveastxt : save Heatwave Event data as txt file

% load target country mask file
load('./result/mask_map')

start_y=find(ismember(heatwave_data(:,1),num2str(start_year))>0);
end_y=find(ismember(heatwave_data(:,1),num2str(end_year))>0);
%
matrix=[];
%%
h = figure('name','Events');
set(gcf,'color','w','units','normalized','position',[0.05 0.05 0.75 0.85],'paperpositionmode','auto');
%%
for year=start_y:end_y
    
    for i=2:size(heatwave_data,2)
        if heatwave_data{year,i}==-1     % -1 means NAN temperature data
            matrix(year,i-1)=nan;
        else
            matrix(year,i-1)=length(heatwave_data{year,i});  %  number of heatwave event
        end
    end
    matrix_copy=matrix;
    buni=reshape(mask_map,1,[]);
    %apply mask file on matrix data
    matrix(year,find(buni==0))=nan;%0;min(min(data));
end
%
n = max(max(matrix));
if ~isempty(find(matrix==-1))
    heatwavecolormap=[[0,0,0;1,1,1];[ones(n-1,1) linspace(1,0,n-1)' zeros(n-1,1)]];%cmap];
else
    heatwavecolormap=[[1,1,1];[ones(n-1,1) linspace(1,0,n-1)' zeros(n-1,1)]];%cmap];
end
% plot each heatwave
m=0;
for year=start_y:end_y
    m=m+1;
    dd=matrix(year,:);
    data=reshape(dd,size(mask_map,1),size(mask_map,2));
    %%
    if m==1
        Position=[0.1,0.75,0.2,0.2];
    else
        pos=get(fig(m-1),'position');
        newpos=[pos(1)+pos(3)+0.1,pos(2),pos(3),pos(4)];
        if newpos(1)>0.95
            newpos=[0.1, pos(2)-pos(4)-0.1,pos(3), pos(4) ];
        end
        Position=newpos;
    end
    %
    fig(m)=scrollsubplot(m,Position);
    %%
    data2=transpose(data);
    img_=imagesc(flipud(data2));
    %
    set(img_,'Xdata',[min(lon_con) max(lon_con)])
    xlim([min(lon_con) max(lon_con)]);
    %
    set(img_,'ydata',[min(lat_con) max(lat_con)])
    ylim([min(lat_con) max(lat_con)]);
    set (gca,'YDir','normal')
    colormap(fig(m),heatwavecolormap);
    hold on
    plot(lon_con,lat_con,'LineWidth',2)
    title(strcat('# Heatwave ', {' '} , num2str(heatwave_data{year,1})))
    xlabel('Longitude')
    ylabel('Latitude')
    if save_fig==1
        filename=sprintf('./result/figures/fig_%s_%s.jpg','Events',num2str(heatwave_data{year,1}));
        title_name=strcat('# Heatwave ', {' '} , num2str(heatwave_data{year,1}));
        save_each_fig(data2,filename,title_name,lon_con,lat_con,heatwavecolormap,min(min(matrix)),n)
    end
    %
    min_value=min(min(matrix_copy));
    if min_value==n
        n=n+0.01*n;
        min_value=min_value-0.01*min_value;
    end
    caxis([min_value n]);
    pause(0.2)
end

colorbar('Position', [0.92  0.2  0.02  0.7])

% if saveastxt==1
%     fclose(fid);
% end
%% $$$$$$$$$$$$$$$$$$$$$$$$   scrollbar   $$$$$$$$$$$$$$$$$$
function ax =scrollsubplot(thisPlot,position)
ax = axes('units','normal','Position', position);
set(ax,'units',get(gcf,'defaultaxesunits'));

scroll_ = findall(gcf,'Type','uicontrol','Tag','scrollbar');

if isempty(scroll_)
    uicontrol('Units','normalized',...
        'Style','Slider',...
        'Position',[.98,0,.02,1],...
        'Min',0,...
        'Max',1,...
        'Value',1,...
        'visible','off',...
        'Tag','scrollbar',...
        'Callback',@(scr,event) scroll(1));
end
%
if ( 9 < thisPlot || thisPlot < 1 )
    set(scroll_,'visible','on')
end
scroll(1)
set(scroll_,'value',1)

function scroll(vauel)
ui_hndl_callback = findall(gcf,'Type','uicontrol','Tag','scrollbar');
axis_ = findall(gcf,'Type','axes');

for ii = length(axis_):-1:1
    a_pos(ii,:) = get(axis_(ii),'position');
end

pos_y_range = [min(.07,min(a_pos(:,2))) max(a_pos(:,2) + a_pos(:,4) )+.07-.9];

val = get(ui_hndl_callback,'value');
step = ( vauel - val) * diff(pos_y_range);


for ii = 1:length(axis_),
    set(axis_(ii),'position',get(axis_(ii),'position') + [0 step 0 0]);
end

set(ui_hndl_callback,'callback',@(scr,event) scroll(val));

%% $$$$$$$$$$$$$$$$$$$$$$$$   extract_data   $$$$$$$$$$$$$$$$$
function [data_tmax,data_tmin]=extract_data(dir_tmax,dir_tmin,lat_country,lon_country)
%purpose : Extract temperature data (Tmax,Tmin)

%Input :
% dir_tmax : max Temperature data directory
% dir_tmin : min Temperature data directory
% lat_country : latitude coordinate of selected area(country)
% lon_country : longitude coordinate of selected area(country)

%
h_waiter = waitbar(0,'Please wait...','Name','Process Extracting Data');
%
max_Pos=max(lon_country(lon_country>0));
min_Pos=min(lon_country(lon_country>0));
max_Neg=max(lon_country(lon_country<0));
min_Neg=min(lon_country(lon_country<0));
%
lat_data=[];
if ~isempty(dir_tmax)
    files_tmax=dir(strcat(dir_tmax,'/*.nc'));
    lat_data=ncread(fullfile(dir_tmax,files_tmax(1).name),'lat');
    long_data=ncread(fullfile(dir_tmax,files_tmax(1).name),'lon');
    files=files_tmax;
end
if ~isempty(dir_tmin)
    files_tmin=dir(strcat(dir_tmin,'/*.nc'));
    if isempty(lat_data)
        lat_data=ncread(fullfile(dir_tmin,files_tmin(1).name),'lat');
        long_data=ncread(fullfile(dir_tmin,files_tmin(1).name),'lon');
        files=files_tmin;
    end
end
% if ~isempty(dir_tmean)
%     files_tmean=dir(strcat(dir_tmean,'/*.nc'));
%     if isempty(lat_data)
%         lat_data=ncread(fullfile(dir_tmean,files_tmean(1).name),'lat');
%         long_data=ncread(fullfile(dir_tmean,files_tmean(1).name),'lon');
%         files=files_tmean;
%     end
% end
%%
if ~isempty(max_Pos) && isempty(max_Neg)  %country in positive longitude like Iran
    [~,max_long]=min(abs(long_data-max_Pos));
    [~,min_long]=min(abs(long_data-min_Pos));
    min_long=min_long-1;
    max_long=max_long+1;
elseif isempty(max_Pos) && ~isempty(max_Neg)  %country in Negative longitude like Argentina
    long_data(long_data>180)=long_data(long_data>180)-360;
    [~,min_long]=min(abs(long_data-min_Neg));
    [~,max_long]=min(abs(long_data-max_Neg));
    min_long=min_long-1;
    max_long=max_long+1;
elseif ~isempty(max_Pos) && ~isempty(max_Neg)  %country in both pos and neg longitude like usa
    long_data(long_data>180)=long_data(long_data>180)-360;
    if ~isempty(find(lon_country<0 & lon_country>-30))%min_Pos<90
        [~,min_long]=min(abs(long_data-min_Neg));
        [~,max_long]=min(abs(long_data-max_Pos));
        min_long=min_long-1;
        max_long=max_long+1;
    elseif isempty(find(lon_country<0 & lon_country>-30))%min_Pos>90
        [~,min_long]=min(abs(long_data-min_Pos));
        [~,max_long]=min(abs(long_data-max_Neg));
        min_long=min_long-1;
        max_long=max_long+1;
    else
        disp('error2')
    end
else
    disp('error')
end
%
if max_long>size(long_data,1)
    max_long=size(long_data,1);
end
if min_long<1
    min_long=1;
end
[~,lat_(1)]=min(abs(lat_data-max(lat_country)));
[~,lat_(2)]=min(abs(lat_data-min(lat_country)));
min_lati=min(lat_)-1;
max_lati= max(lat_)+1;
%%
j=0;
data_tmax=[];
data_tmin=[];
data_tmean=[];
j=j+1;
%
for i=1:length(files)
    filename=files(i).name;
    split_filename=strsplit(filename,'.');
    filedate=split_filename{length(split_filename)-1};%%%filename(regexp(filename,['\d']));
    %%
    %max temperature
    if ~isempty(dir_tmax)
        temp_data_max=ncread(fullfile(dir_tmax,files_tmax(i).name), 'tmax');
        if max_long<min_long
            longi_=[min_long:720,1:max_long];
            country_data_temp_max=temp_data_max(longi_,min_lati:max_lati,:);
        else
            country_data_temp_max=temp_data_max(min_long:max_long,min_lati:max_lati,:);
        end
        country_data_temp_max(country_data_temp_max<-1000)=nan;
        country_data_temp_max(country_data_temp_max>1000)=nan;
        data_tmax{1,j}{i,1}=filedate;
        data_tmax{1,j}{i,2}=country_data_temp_max;
        temp_data_max='';
    end
    %%
    % min temperature
    if ~isempty(dir_tmin)
        temp_data_min=ncread(fullfile(dir_tmin,files_tmin(i).name), 'tmin');
        if max_long<min_long
            longi_=[min_long:720,1:max_long];
            country_data_temp_min=temp_data_min(longi_,min_lati:max_lati,:);
        else
            country_data_temp_min=temp_data_min(min_long:max_long,min_lati:max_lati,:);
        end
        country_data_temp_min(country_data_temp_min<-1000)=nan;
        country_data_temp_min(country_data_temp_min>1000)=nan;
        data_tmin{1,j}{i,1}=filedate;
        data_tmin{1,j}{i,2}=country_data_temp_min;
        temp_data_min='';
    end
    %%
%     % mean temperature
%     if ~isempty(dir_tmean)
%         temp_data_mean=ncread(fullfile(dir_tmean,files_tmean(i).name), config{5,2});
%         if max_long<min_long
%             longi_=[min_long:720,1:max_long];
%             country_data_temp_mean=temp_data_mean(longi_,min_lati:max_lati,:);
%         else
%             country_data_temp_mean=temp_data_mean(min_long:max_long,min_lati:max_lati,:);
%         end
%         country_data_temp_mean(country_data_temp_mean<-1000)=nan;
%         country_data_temp_mean(country_data_temp_mean>1000)=nan;
%         data_tmean{1,j}{i,1}=filedate;
%         data_tmean{1,j}{i,2}=country_data_temp_mean;
%         temp_data_mean='';
%     end
    %%
    disp(strcat('Extract data : ',num2str(filedate)))
    waitbar(i/length(files));
end
if ~isempty(dir_tmax)
    save('./result/data_tmax','data_tmax','-v7.3')
end
if ~isempty(dir_tmin)
    save('./result/data_tmin','data_tmin','-v7.3')
end
% if ~isempty(dir_tmean)
%     data_combined=data_tmean;
%     save('./result/data_combined','data_combined','-v7.3')
% end
save('./result/lat_data','lat_data','-v7.3')
delete(h_waiter)
