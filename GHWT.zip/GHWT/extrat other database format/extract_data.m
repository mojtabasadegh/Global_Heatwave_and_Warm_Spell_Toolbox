clc
clear
if ~exist('../result')
    mkdir('../result')
end
%% model variable
file_id=fopen('config.txt');
file_data=fread(file_id,'*char')';
fclose(file_id);
split_data=strsplit(file_data,'\n');
for ll=1:length(split_data)
    if ~isempty(split_data{1,ll}) && strcmp(split_data{1,ll},char(13))==0 && strcmp(split_data{1,ll}(1:2),'//')==0
        key_part=split_data{1,ll}(1:strfind(split_data{1,ll},'=')-1);
        value_part=split_data{1,ll}(strfind(split_data{1,ll},'=')+1:length(split_data{1,ll}));
        eval([key_part '=',strrep(value_part,char(13),''),';']);
    end
end
%
data_file_start_date=datetime(double(datafile_start_year),double(datafile_start_month),double(datafile_start_day));
data_file_end_date=datetime(double(datafile_end_year),double(datafile_end_month),double(datafile_end_day));
shapefile_shape=shaperead(shapefile_directory);
list_files=dir(fullfile(ncfile_directory,'*.nc'));
target_coordinate=[{shapefile_shape(country_index_in_shapefile).X},{shapefile_shape(country_index_in_shapefile).Y}];
%% target country lat amd long data
lat_country=shapefile_shape(country_index_in_shapefile).Y;
lon_country=shapefile_shape(country_index_in_shapefile).X;
%
max_Pos=max(lon_country(lon_country>0));
min_Pos=min(lon_country(lon_country>0));
max_Neg=max(lon_country(lon_country<0));
min_Neg=min(lon_country(lon_country<0));
%% nc file lat and long data
lat_data=ncread(fullfile(ncfile_directory,list_files(1).name),'lat');
long_data=ncread(fullfile(ncfile_directory,list_files(1).name),'lon');
%%
if ~isempty(max_Pos) && isempty(max_Neg)  %country in positive longitude like Iran
    [~,max_long]=min(abs(long_data-max_Pos));
    [~,min_long]=min(abs(long_data-min_Pos));
    min_long=min_long-1;
    max_long=max_long+1;
elseif isempty(max_Pos) && ~isempty(max_Neg)  %country in Negative longitude like Argentina
    long_data(long_data>180)=long_data(long_data>180)-360;
    [~,min_long]=min(abs(long_data-min_Neg));
    [~,max_long]=min(abs(long_data-max_Neg));
    min_long=min_long-1;
    max_long=max_long+1;
elseif ~isempty(max_Pos) && ~isempty(max_Neg)  %country in both pos and neg longitude like algeria
    long_data(long_data>180)=long_data(long_data>180)-360;
    if ~isempty(find(lon_country<0 & lon_country>-30))%min_Pos<90
        [~,min_long]=min(abs(long_data-min_Neg));
        [~,max_long]=min(abs(long_data-max_Pos));
        min_long=min_long-1;
        max_long=max_long+1;
    elseif isempty(find(lon_country<0 & lon_country>-30))%min_Pos>90
        [~,min_long]=min(abs(long_data-min_Pos));
        [~,max_long]=min(abs(long_data-max_Neg));
        min_long=min_long-1;
        max_long=max_long+1;
    else
        disp('error2')
    end
else
    disp('error')
end
%
if max_long>size(long_data,1)
    max_long=size(long_data,1);
end
if min_long<1
    min_long=1;
end
[~,lat_(1)]=min(abs(lat_data-max(lat_country)));
[~,lat_(2)]=min(abs(lat_data-min(lat_country)));
min_lati=min(lat_)-1;
max_lati= max(lat_)+1;
%%  Extract Data
country_data_temp_=[];
for file_index=1:length(list_files)
    temporary_data=ncread(fullfile(ncfile_directory,list_files(file_index).name),feature_name);
    country_data_temp_temporary=[];
    if max_long<min_long
        longi_=[min_long:720,1:max_long];
        country_data_temp_temporary=temporary_data(longi_,min_lati:max_lati,:);
    else
        country_data_temp_temporary=temporary_data(min_long:max_long,min_lati:max_lati,:);
    end
    country_data_temp_temporary(country_data_temp_temporary<-1000)=nan;
    country_data_temp_temporary(country_data_temp_temporary>1000)=nan;
    if lat_data(1)<0 % if latitude of nc file data start from -90 to +90, flip up down them
        country_data_temp_temporary=fliplr(country_data_temp_temporary);
    end
    if isempty(country_data_temp_)
        start_index=0;
    else
        start_index=size(country_data_temp_,3);
    end
    end_index=size(temporary_data,3);
    country_data_temp_(:,:,start_index+1:start_index+end_index)=country_data_temp_temporary;
end
%load country_data_temp_
data_={};
j=1;
index_s=1;
index_e=0;
for year_index=data_file_start_date.Year:data_file_end_date.Year
    index_e=index_e + days(datetime(year_index+1,01,01)-datetime(year_index,01,01));
    if index_e>size(country_data_temp_,3)
        index_e= size(country_data_temp_,3);
    end
    data_{1,1}{j,1}=num2str(year_index);
    data_{1,1}{j,2}=country_data_temp_(:,:,index_s:index_e);
    index_s=index_e+1;
    j=j+1;
end
eval([save_name '=data_;']);
save(strcat('../result/', save_name),save_name,'-v7.3');
save('../result/lat_data','lat_data','-v7.3')
save('../result/coordinate','target_coordinate','-v7.3')
%%  Create Mask File
% get nc file lat,long properties
first_long=long_data(1);
last_long=long_data(length(long_data));
first_lat=lat_data(1);
last_lat=lat_data(length(lat_data));
long_accuracy=long_data(2)-long_data(1);
lat_accuracy=lat_data(2)-lat_data(1);
%
if max_long<min_long         % country like algeria that have +- longitude coordinates
    longi_=[min_long:length(long_data),1:max_long];
    mask_map=zeros(length(longi_),max_lati-min_lati+1);
    for i=longi_
        for j=min_lati:max_lati
            lon_cor=first_long+(i-1)*long_accuracy;%0.25+(i-1)*0.5;
            lat_cor=first_lat+(j-1)*lat_accuracy;%89.75-(j-1)*0.5;
            if lon_cor>180
                lon_cor=lon_cor-360;
            end
            status=inpolygon(lon_cor,lat_cor,lon_country,lat_country);
            if status==1
                if i<min_long
                    x_ind=length(long_data)-min_long+i+1;
                    y_ind=j-min_lati+1;
                    mask_map(x_ind,y_ind)=1;
                else
                    x_ind=i-min_long+1;
                    y_ind=j-min_lati+1;
                    mask_map(x_ind,y_ind)=1;
                end
                try
                    mask_map(x_ind-1,y_ind-1)=1;
                    mask_map(x_ind-1,y_ind+0)=1;
                    mask_map(x_ind-1,y_ind+1)=1;
                    %
                    mask_map(x_ind+1,y_ind-1)=1;
                    mask_map(x_ind+1,y_ind+0)=1;
                    mask_map(x_ind+1,y_ind+1)=1;
                    %
                    mask_map(x_ind,y_ind-1)=1;
                    mask_map(x_ind,y_ind+1)=1;
                end
            end
        end
        waitbar(find(i==longi_)/length(longi_));
    end
else
    mask_map=zeros(max_long-min_long+1,max_lati-min_lati+1);
    %min_long=355;
    for i=min_long:max_long
        for j=min_lati:max_lati
            lon_cor=first_long+(i-1)*long_accuracy;%0.25+(i-1)*0.5;
            lat_cor=first_lat+(j-1)*lat_accuracy;%89.75-(j-1)*0.5;
            
            if lon_cor>180
                lon_cor=lon_cor-360;
            end
            status=inpolygon(lon_cor,lat_cor,lon_country,lat_country);
            if status==1
                x_ind=i-min_long+1;
                y_ind=j-min_lati+1;
                %center
                mask_map(x_ind,y_ind)=1;
                %
                try
                    mask_map(x_ind-1,y_ind-1)=1;
                    mask_map(x_ind-1,y_ind+0)=1;
                    mask_map(x_ind-1,y_ind+1)=1;
                    %
                    mask_map(x_ind+1,y_ind-1)=1;
                    mask_map(x_ind+1,y_ind+0)=1;
                    mask_map(x_ind+1,y_ind+1)=1;
                    %
                    mask_map(x_ind,y_ind-1)=1;
                    mask_map(x_ind,y_ind+1)=1;
                end
            end
        end
        %waitbar((i-min_long)/(max_long-min_long));
    end
end
if size(mask_map,1)-size(country_data_temp_temporary,1)==1
    mask_map=mask_map(1:end-1,:);
end
if lat_data(1)<0 % if latitude of nc file data start from -90 to +90, flip up down them
    mask_map=fliplr(mask_map);
end
save('../result/mask_map','mask_map');