clc
clear
%
%% 2:Method
handles.radio_temp=1; % Temperature method
handles.radio_pdf=0; % PDF method
handles.radio_summer=0; % Summer method
handles.radio_ehf=0; % EHF method
%% 3:Data type
handles.radio_tmean=0; % Mean temperature
handles.radio_tmax=1; % Max temperature
handles.radio_tmin=0; % Min temperature
%% 4: Model parameters
handles.txt_temperature=20; % Temperature
handles.txt_consecusive_day=4; % Consecutive day
handles.txt_plusminus=10; % PDF plusminus
handles.txt_percentile_threshold=85; % Percentile threshold
handles.txt_ehfscale=0; % EHF scale
%% 5: Summer setting
handles.txt_summer_start='01-May-2017'; % start summer in Northern hemisphere
handles.txt_summer_end='01-Sep-2017'; % end summer in Northern hemisphere
handles.txt_summer_start_s='01-Dec-2017'; % start summer in Southern hemisphere
handles.txt_summer_end_s='28-Feb-2017'; % end summer in Southern hemisphere
%% 6: Output parameters
handles.chk_eachfig=0; % save figures
handles.startyear=2000; % Start year
handles.endyear=2017; % End year
%% Run
GHWT_script(handles)

